public class WP_Block_Parser_Block
{
    public string BlockName { get; set; }
    public Dictionary<string, object> Attrs { get; set; }
    public List<WP_Block_Parser_Block> InnerBlocks { get; set; }
    public string InnerHTML { get; set; }
    public List<object> InnerContent { get; set; } // Can be string or null

    public WP_Block_Parser_Block()
    {
        InnerBlocks = new List<WP_Block_Parser_Block>();
        InnerContent = new List<object>();
        Attrs = new Dictionary<string, object>();
    }
}