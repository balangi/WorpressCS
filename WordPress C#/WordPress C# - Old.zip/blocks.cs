using System;
using System.Collections.Generic;

public class WP_Block
{
    public WP_Block_Parser_Block ParsedBlock { get; }
    public Dictionary<string, object> Context { get; }
    public WP_Block_Type BlockType { get; }

    public WP_Block(WP_Block_Parser_Block parsedBlock, Dictionary<string, object> context)
    {
        ParsedBlock = parsedBlock;
        Context = context ?? new Dictionary<string, object>();
        BlockType = WP_Block_Type_Registry.Instance.GetRegistered(parsedBlock.BlockName);
    }

    public string Render()
    {
        // Apply filters similar to PHP's apply_filters('pre_render_block')
        var preRender = ApplyPreRenderFilters(null, ParsedBlock, null);
        if (preRender != null)
            return preRender;

        // Process block data
        var processedBlock = ApplyRenderBlockDataFilters(ParsedBlock);

        // If block has a render callback, use it
        if (BlockType?.RenderCallback != null)
        {
            return BlockType.RenderCallback(processedBlock.Attributes, processedBlock.InnerHTML, this);
        }

        // Otherwise, render inner blocks
        string blockContent = "";
        int index = 0;
        foreach (var chunk in processedBlock.InnerContent)
        {
            if (chunk is string)
            {
                blockContent += chunk;
            }
            else
            {
                if (index < processedBlock.InnerBlocks.Count)
                {
                    var innerBlock = processedBlock.InnerBlocks[index];
                    blockContent += new WP_Block(innerBlock, Context).Render();
                    index++;
                }
            }
        }

        return GetCommentDelimitedBlockContent(
            processedBlock.BlockName,
            processedBlock.Attributes,
            blockContent
        );
    }

    private string ApplyPreRenderFilters(string preRender, WP_Block_Parser_Block parsedBlock, WP_Block parentBlock)
    {
        // Implement filter application logic
        // In a real application, this would use a proper event/delegate system
        return preRender;
    }

    private WP_Block_Parser_Block ApplyRenderBlockDataFilters(WP_Block_Parser_Block parsedBlock)
    {
        // Implement filter application logic
        return parsedBlock;
    }

    private string GetCommentDelimitedBlockContent(string blockName, Dictionary<string, object> attributes, string blockContent)
    {
        // Implementation similar to PHP's get_comment_delimited_block_content
        string serializedName = StripCoreBlockNamespace(blockName);
        string serializedAttributes = SerializeBlockAttributes(attributes);

        if (string.IsNullOrEmpty(blockContent))
        {
            return $"<!-- wp:{serializedName} {serializedAttributes}/-->";
        }

        return $"<!-- wp:{serializedName} {serializedAttributes}-->{blockContent}<!-- /wp:{serializedName} -->";
    }

    private string StripCoreBlockNamespace(string blockName)
    {
        if (blockName?.StartsWith("core/") == true)
        {
            return blockName.Substring(5);
        }
        return blockName;
    }

    private string SerializeBlockAttributes(Dictionary<string, object> attributes)
    {
        if (attributes == null || attributes.Count == 0)
            return "";

        // Use System.Text.Json for serialization
        var options = new System.Text.Json.JsonSerializerOptions
        {
            WriteIndented = false,
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        };

        string json = System.Text.Json.JsonSerializer.Serialize(attributes, options);
        
        // Perform the same replacements as in PHP
        json = json.Replace("--", "\\u002d\\u002d")
                   .Replace("<", "\\u003c")
                   .Replace(">", "\\u003e")
                   .Replace("&", "\\u0026")
                   .Replace("\\\"", "\\u0022");

        return json;
    }
}