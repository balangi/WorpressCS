using System;
using System.Collections.Generic;

public class WP_Block_Styles_Registry
{
    private static WP_Block_Styles_Registry _instance;
    private Dictionary<string, List<BlockStyle>> _registeredStyles = new Dictionary<string, List<BlockStyle>>();

    public static WP_Block_Styles_Registry Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new WP_Block_Styles_Registry();
            }
            return _instance;
        }
    }

    public bool Register(string blockName, BlockStyle styleProperties)
    {
        return Register(blockName, new[] { styleProperties });
    }

    public bool Register(string blockName, IEnumerable<BlockStyle> styleProperties)
    {
        if (string.IsNullOrEmpty(blockName)) return false;
        
        if (!_registeredStyles.TryGetValue(blockName, out var styles))
        {
            styles = new List<BlockStyle>();
            _registeredStyles[blockName] = styles;
        }

        styles.AddRange(styleProperties);
        return true;
    }

    public bool Unregister(string blockName, string styleName)
    {
        if (_registeredStyles.TryGetValue(blockName, out var styles))
        {
            int removed = styles.RemoveAll(s => s.Name == styleName);
            return removed > 0;
        }
        return false;
    }

    public List<BlockStyle> GetRegisteredStyles(string blockName)
    {
        if (_registeredStyles.TryGetValue(blockName, out var styles))
        {
            return new List<BlockStyle>(styles);
        }
        return new List<BlockStyle>();
    }
}