public class BlockMetadata : Dictionary<string, object>
{
    public string File { get; set; }
    public string Name => ContainsKey("name") ? this["name"].ToString() : null;
    public string Version => ContainsKey("version") ? this["version"].ToString() : null;
    public string TextDomain => ContainsKey("textdomain") ? this["textdomain"].ToString() : null;
}