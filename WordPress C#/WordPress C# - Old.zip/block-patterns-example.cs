// در Startup.cs یا Program.cs
builder.Services.AddSingleton<BlockPatternsRegistry>();
builder.Services.AddScoped<BlockPatternsService>();
builder.Services.AddDbContext<AppDbContext>();

// در جایی که نیاز به مقداردهی اولیه داریم
var patternsService = serviceProvider.GetRequiredService<BlockPatternsService>();
patternsService.InitializeCorePatterns();
patternsService.RegisterCoreCategories();
await patternsService.LoadRemotePatternsAsync();

// نمونه کوئری‌های LINQ برای دسترسی به الگوها
using var context = new AppDbContext();

// دریافت همه الگوهای یک دسته‌بندی خاص
var bannerPatterns = context.BlockPatterns
    .Where(p => EF.Functions.JsonContains(p.CategoriesJson, "\"banner\""))
    .ToList();

// دریافت همه دسته‌بندی‌ها
var categories = context.BlockPatternCategories
    .OrderBy(c => c.Label)
    .ToList();