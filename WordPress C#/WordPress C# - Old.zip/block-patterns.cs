public class BlockPatternsRegistry
{
    private static readonly Lazy<BlockPatternsRegistry> _instance = 
        new Lazy<BlockPatternsRegistry>(() => new BlockPatternsRegistry());
    
    public static BlockPatternsRegistry Instance => _instance.Value;
    
    private readonly Dictionary<string, BlockPattern> _patterns = new();
    private readonly Dictionary<string, BlockPatternCategory> _categories = new();

    public bool RegisterPattern(BlockPattern pattern)
    {
        if (string.IsNullOrEmpty(pattern.Name) 
            throw new ArgumentException("Pattern name cannot be null or empty");
        
        if (_patterns.ContainsKey(pattern.Name))
            return false;
        
        _patterns[pattern.Name] = pattern;
        return true;
    }

    public bool UnregisterPattern(string name)
    {
        return _patterns.Remove(name);
    }

    public bool IsPatternRegistered(string name)
    {
        return _patterns.ContainsKey(name);
    }

    public BlockPattern GetPattern(string name)
    {
        return _patterns.TryGetValue(name, out var pattern) ? pattern : null;
    }

    public IEnumerable<BlockPattern> GetAllPatterns()
    {
        return _patterns.Values;
    }

    public bool RegisterCategory(BlockPatternCategory category)
    {
        if (string.IsNullOrEmpty(category.Name))
            throw new ArgumentException("Category name cannot be null or empty");
        
        if (_categories.ContainsKey(category.Name))
            return false;
        
        _categories[category.Name] = category;
        return true;
    }

    public bool UnregisterCategory(string name)
    {
        return _categories.Remove(name);
    }

    public IEnumerable<BlockPatternCategory> GetAllCategories()
    {
        return _categories.Values;
    }
}