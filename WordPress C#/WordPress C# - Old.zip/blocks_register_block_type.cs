public static WP_Block_Type RegisterBlockType(string blockType, Dictionary<string, object> args = null)
{
    args = args ?? new Dictionary<string, object>();

    // If blockType is a path to a JSON file
    if (System.IO.File.Exists(blockType))
    {
        return RegisterBlockTypeFromMetadata(blockType, args);
    }

    return WP_Block_Type_Registry.Instance.Register(blockType, new WP_Block_Type(blockType, args));
}