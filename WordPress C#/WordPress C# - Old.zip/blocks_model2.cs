public class WP_Post
{
    public int Id { get; set; }
    public string PostType { get; set; }
    public string PostContent { get; set; }
    // Other properties...
}