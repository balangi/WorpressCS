public class AppDbContext : DbContext
{
    public DbSet<BlockPatternEntity> BlockPatterns { get; set; }
    public DbSet<BlockPatternCategoryEntity> BlockPatternCategories { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Server=...;Database=...;...");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Configure JSON serialization for list properties
        modelBuilder.Entity<BlockPatternEntity>()
            .Property(e => e.CategoriesJson)
            .HasConversion(
                v => JsonSerializer.Serialize(v, null),
                v => JsonSerializer.Deserialize<List<string>>(v, null));
        
        modelBuilder.Entity<BlockPatternEntity>()
            .Property(e => e.BlockTypesJson)
            .HasConversion(
                v => JsonSerializer.Serialize(v, null),
                v => JsonSerializer.Deserialize<List<string>>(v, null));
        
        // Similar conversions for PostTypesJson and TemplateTypesJson
    }
}