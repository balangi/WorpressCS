using System;
using System.Collections.Generic;

public class WP_Block_Type_Registry
{
    private static WP_Block_Type_Registry _instance;
    private Dictionary<string, WP_Block_Type> _registeredBlocks = new Dictionary<string, WP_Block_Type>();
    private Dictionary<string, BlockMetadataCollection> _metadataCollections = new Dictionary<string, BlockMetadataCollection>();

    public static WP_Block_Type_Registry Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new WP_Block_Type_Registry();
            }
            return _instance;
        }
    }

    public bool Register(string blockName, WP_Block_Type blockType)
    {
        if (string.IsNullOrEmpty(blockName) return false;
        if (_registeredBlocks.ContainsKey(blockName)) return false;
        
        _registeredBlocks[blockName] = blockType;
        return true;
    }

    public bool Unregister(string blockName)
    {
        return _registeredBlocks.Remove(blockName);
    }

    public WP_Block_Type GetRegistered(string blockName)
    {
        _registeredBlocks.TryGetValue(blockName, out var blockType);
        return blockType;
    }

    public Dictionary<string, WP_Block_Type> GetAllRegistered()
    {
        return new Dictionary<string, WP_Block_Type>(_registeredBlocks);
    }

    // Methods for metadata collections
    public void RegisterCollection(string path, string manifestPath)
    {
        // Load metadata from manifest and store it
        var metadata = LoadMetadataCollection(manifestPath);
        _metadataCollections[path] = metadata;
    }

    public BlockMetadata GetMetadata(string fileOrFolder)
    {
        foreach (var collection in _metadataCollections.Values)
        {
            if (collection.TryGetValue(fileOrFolder, out var metadata))
            {
                return metadata;
            }
        }
        return null;
    }

    public List<string> GetCollectionBlockMetadataFiles(string path)
    {
        if (_metadataCollections.TryGetValue(path, out var collection))
        {
            return collection.GetAllMetadataFiles();
        }
        return new List<string>();
    }

    private BlockMetadataCollection LoadMetadataCollection(string manifestPath)
    {
        // Implementation to load metadata from JSON manifest
        // This would typically use System.Text.Json or Newtonsoft.Json
        return new BlockMetadataCollection();
    }
}

public class BlockMetadataCollection
{
    private Dictionary<string, BlockMetadata> _metadata = new Dictionary<string, BlockMetadata>();

    public bool TryGetValue(string key, out BlockMetadata metadata)
    {
        return _metadata.TryGetValue(key, out metadata);
    }

    public List<string> GetAllMetadataFiles()
    {
        return _metadata.Keys.ToList();
    }

    // Other methods to populate the collection from JSON
}