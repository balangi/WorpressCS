[Table("BlockPatterns")]
public class BlockPatternEntity
{
    [Key]
    [StringLength(255)]
    public string Name { get; set; }

    [Required]
    [StringLength(255)]
    public string Title { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string Description { get; set; }

    [Required]
    [Column(TypeName = "nvarchar(max)")]
    public string Content { get; set; }

    [StringLength(100)]
    public string Source { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string CategoriesJson { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string BlockTypesJson { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string PostTypesJson { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string TemplateTypesJson { get; set; }

    public int? ViewportWidth { get; set; }

    [StringLength(500)]
    public string FilePath { get; set; }
}