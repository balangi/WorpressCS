public static Dictionary<string, object> BuildCommentQueryVarsFromBlock(WP_Block block)
{
    var commentArgs = new Dictionary<string, object>
    {
        {"orderby", "comment_date_gmt"},
        {"order", "ASC"},
        {"status", "approve"},
        {"no_found_rows", false}
    };

    if (IsUserLoggedIn())
    {
        commentArgs["include_unapproved"] = new[] { GetCurrentUserId() };
    }
    else
    {
        var unapprovedEmail = GetUnapprovedCommentAuthorEmail();
        if (!string.IsNullOrEmpty(unapprovedEmail))
        {
            commentArgs["include_unapproved"] = new[] { unapprovedEmail };
        }
    }

    if (block.Context.TryGetValue("postId", out object postIdObj) && postIdObj is int postId)
    {
        commentArgs["post_id"] = postId;
    }

    if (GetOption<bool>("thread_comments"))
    {
        commentArgs["hierarchical"] = "threaded";
    }
    else
    {
        commentArgs["hierarchical"] = false;
    }

    if (GetOption<bool>("page_comments"))
    {
        int perPage = GetOption<int>("comments_per_page");
        string defaultPage = GetOption<string>("default_comments_page");

        if (perPage > 0)
        {
            commentArgs["number"] = perPage;

            int page = GetQueryVar<int>("cpage");
            if (page > 0)
            {
                commentArgs["paged"] = page;
            }
            else if (defaultPage == "oldest")
            {
                commentArgs["paged"] = 1;
            }
            else if (defaultPage == "newest")
            {
                var query = new WP_Comment_Query(commentArgs);
                if (query.MaxNumPages > 0)
                {
                    commentArgs["paged"] = query.MaxNumPages;
                }
            }
        }
    }

    return commentArgs;
}

private static bool IsUserLoggedIn()
{
    // Implementation would check if user is logged in
    return false;
}

private static int GetCurrentUserId()
{
    // Implementation would get current user ID
    return 0;
}

private static string GetUnapprovedCommentAuthorEmail()
{
    // Implementation would get unapproved comment author email
    return null;
}

private static T GetQueryVar<T>(string varName)
{
    // Implementation would get query var
    return default;
}