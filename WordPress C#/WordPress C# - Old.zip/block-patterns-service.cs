public class BlockPatternsService
{
    private readonly BlockPatternsRegistry _registry;
    private readonly AppDbContext _dbContext;
    private readonly IWebHostEnvironment _env;

    public BlockPatternsService(
        BlockPatternsRegistry registry, 
        AppDbContext dbContext,
        IWebHostEnvironment env)
    {
        _registry = registry;
        _dbContext = dbContext;
        _env = env;
    }

    public void InitializeCorePatterns()
    {
        // Check if theme supports core patterns
        var supportsCorePatterns = true; // This should come from theme settings
        
        if (supportsCorePatterns)
        {
            var corePatterns = new[]
            {
                "query-standard-posts",
                "query-medium-posts",
                "query-small-posts",
                "query-grid-posts",
                "query-large-title-posts",
                "query-offset-posts"
            };

            foreach (var patternName in corePatterns)
            {
                var pattern = LoadPatternFromFile($"block-patterns/{patternName}.json");
                if (pattern != null)
                {
                    pattern.Source = "core";
                    _registry.RegisterPattern(pattern);
                    SavePatternToDatabase(pattern);
                }
            }
        }
    }

    public void RegisterCoreCategories()
    {
        var categories = new[]
        {
            new BlockPatternCategory
            {
                Name = "banner",
                Label = "Banners",
                Description = "Bold sections designed to showcase key content."
            },
            new BlockPatternCategory
            {
                Name = "buttons",
                Label = "Buttons",
                Description = "Patterns that contain buttons and call to actions."
            },
            // Add all other categories similarly
        };

        foreach (var category in categories)
        {
            _registry.RegisterCategory(category);
            SaveCategoryToDatabase(category);
        }
    }

    public async Task LoadRemotePatternsAsync()
    {
        var shouldLoadRemote = true; // Can be configured via settings
        
        if (shouldLoadRemote)
        {
            // Load core patterns from remote API
            var corePatterns = await FetchPatternsFromApi("core");
            RegisterPatternsFromApi(corePatterns, "pattern-directory/core");

            // Load featured patterns
            var featuredPatterns = await FetchPatternsFromApi("featured");
            RegisterPatternsFromApi(featuredPatterns, "pattern-directory/featured");
        }
    }

    private BlockPattern LoadPatternFromFile(string relativePath)
    {
        var fullPath = Path.Combine(_env.ContentRootPath, relativePath);
        if (!File.Exists(fullPath))
            return null;

        var json = File.ReadAllText(fullPath);
        return JsonSerializer.Deserialize<BlockPattern>(json);
    }

    private void SavePatternToDatabase(BlockPattern pattern)
    {
        var entity = new BlockPatternEntity
        {
            Name = pattern.Name,
            Title = pattern.Title,
            Description = pattern.Description,
            Content = pattern.Content,
            Source = pattern.Source,
            CategoriesJson = JsonSerializer.Serialize(pattern.Categories),
            BlockTypesJson = JsonSerializer.Serialize(pattern.BlockTypes),
            PostTypesJson = JsonSerializer.Serialize(pattern.PostTypes),
            TemplateTypesJson = JsonSerializer.Serialize(pattern.TemplateTypes),
            ViewportWidth = pattern.ViewportWidth,
            FilePath = pattern.FilePath
        };

        _dbContext.BlockPatterns.Add(entity);
        _dbContext.SaveChanges();
    }

    private void SaveCategoryToDatabase(BlockPatternCategory category)
    {
        var entity = new BlockPatternCategoryEntity
        {
            Name = category.Name,
            Label = category.Label,
            Description = category.Description
        };

        _dbContext.BlockPatternCategories.Add(entity);
        _dbContext.SaveChanges();
    }

    private async Task<List<BlockPattern>> FetchPatternsFromApi(string type)
    {
        // Implement API call to fetch patterns
        // This would use HttpClient to call the pattern directory API
        // and return deserialized patterns
        
        // Mock implementation:
        return new List<BlockPattern>();
    }

    private void RegisterPatternsFromApi(List<BlockPattern> patterns, string source)
    {
        foreach (var pattern in patterns)
        {
            pattern.Source = source;
            
            if (!_registry.IsPatternRegistered(pattern.Name))
            {
                _registry.RegisterPattern(pattern);
                SavePatternToDatabase(pattern);
            }
        }
    }
}