using System;
using System.Collections.Generic;
using System.Linq;

public class QueryBuilder
{
    public static Dictionary<string, object> BuildQueryVarsFromQueryBlock(WP_Block block, int page)
    {
        var query = new Dictionary<string, object>
        {
            {"post_type", "post"},
            {"order", "DESC"},
            {"orderby", "date"},
            {"post__not_in", new List<int>()},
            {"tax_query", new List<Dictionary<string, object>>()}
        };

        if (block.Context.TryGetValue("query", out object queryObj) && queryObj is Dictionary<string, object> queryContext)
        {
            // Post type
            if (queryContext.TryGetValue("postType", out object postTypeObj) && postTypeObj is string postType)
            {
                if (IsPostTypeViewable(postType))
                {
                    query["post_type"] = postType;
                }
            }

            // Sticky posts
            if (queryContext.TryGetValue("sticky", out object stickyObj) && stickyObj is string sticky)
            {
                var stickyPosts = GetOption<int[]>("sticky_posts") ?? Array.Empty<int>();
                
                switch (sticky)
                {
                    case "only":
                        query["post__in"] = stickyPosts.Any() ? stickyPosts : new[] { 0 };
                        query["ignore_sticky_posts"] = 1;
                        break;
                    case "exclude":
                        var excluded = ((List<int>)query["post__not_in"]).Concat(stickyPosts).ToList();
                        query["post__not_in"] = excluded;
                        break;
                    case "ignore":
                        query["ignore_sticky_posts"] = 1;
                        break;
                }
            }

            // Excluded posts
            if (queryContext.TryGetValue("exclude", out object excludeObj) && excludeObj is IEnumerable<object> exclude)
            {
                var excludedIds = exclude.Select(x => Convert.ToInt32(x)).Where(x => x > 0).ToList();
                var currentExcluded = (List<int>)query["post__not_in"];
                currentExcluded.AddRange(excludedIds);
                query["post__not_in"] = currentExcluded;
            }

            // Pagination
            if (queryContext.TryGetValue("perPage", out object perPageObj) && int.TryParse(perPageObj.ToString(), out int perPage))
            {
                int offset = 0;
                if (queryContext.TryGetValue("offset", out object offsetObj) && int.TryParse(offsetObj.ToString(), out int offsetValue))
                {
                    offset = offsetValue;
                }

                query["offset"] = (perPage * (page - 1)) + offset;
                query["posts_per_page"] = perPage;
            }

            // Taxonomy query
            if (queryContext.TryGetValue("taxQuery", out object taxQueryObj) && taxQueryObj is Dictionary<string, object> taxQuery)
            {
                var taxQueries = new List<Dictionary<string, object>>();
                
                foreach (var kvp in taxQuery)
                {
                    if (IsTaxonomyViewable(kvp.Key) && kvp.Value is IEnumerable<object> terms && terms.Any())
                    {
                        taxQueries.Add(new Dictionary<string, object>
                        {
                            {"taxonomy", kvp.Key},
                            {"terms", terms.Select(x => Convert.ToInt32(x)).Where(x => x > 0).ToArray()},
                            {"include_children", false}
                        });
                    }
                }
                
                var currentTaxQueries = (List<Dictionary<string, object>>)query["tax_query"];
                currentTaxQueries.AddRange(taxQueries);
                query["tax_query"] = currentTaxQueries;
            }

            // Order and orderby
            if (queryContext.TryGetValue("order", out object orderObj) && orderObj is string order)
            {
                if (order.ToUpper() == "ASC" || order.ToUpper() == "DESC")
                {
                    query["order"] = order.ToUpper();
                }
            }

            if (queryContext.TryGetValue("orderBy", out object orderByObj))
            {
                query["orderby"] = orderByObj;
            }

            // Author
            if (queryContext.TryGetValue("author", out object authorObj))
            {
                if (authorObj is IEnumerable<object> authorList)
                {
                    query["author__in"] = authorList.Select(x => Convert.ToInt32(x)).Where(x => x > 0).ToArray();
                }
                else if (authorObj is string authorStr)
                {
                    query["author__in"] = authorStr.Split(',').Select(x => Convert.ToInt32(x)).Where(x => x > 0).ToArray();
                }
                else if (authorObj is int authorId && authorId > 0)
                {
                    query["author"] = authorId;
                }
            }

            // Search
            if (queryContext.TryGetValue("search", out object searchObj) && searchObj is string search && !string.IsNullOrEmpty(search))
            {
                query["s"] = search;
            }
        }

        return query;
    }

    private static bool IsPostTypeViewable(string postType)
    {
        // Implementation would check if post type is viewable
        return true;
    }

    private static bool IsTaxonomyViewable(string taxonomy)
    {
        // Implementation would check if taxonomy is viewable
        return true;
    }

    private static T GetOption<T>(string optionName)
    {
        // Implementation would get option from database
        return default;
    }
}