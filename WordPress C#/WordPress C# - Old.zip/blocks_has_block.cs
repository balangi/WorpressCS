public static bool HasBlocks(string postContent)
{
    return !string.IsNullOrEmpty(postContent) && postContent.Contains("<!-- wp:");
}

public static bool HasBlock(string blockName, string postContent)
{
    if (!HasBlocks(postContent))
        return false;

    string normalizedBlockName = blockName;
    if (!blockName.Contains("/"))
    {
        normalizedBlockName = "core/" + blockName;
    }

    bool hasBlock = postContent.Contains($"<!-- wp:{normalizedBlockName} ");

    if (!hasBlock)
    {
        string serializedBlockName = StripCoreBlockNamespace(normalizedBlockName);
        if (serializedBlockName != normalizedBlockName)
        {
            hasBlock = postContent.Contains($"<!-- wp:{serializedBlockName} ");
        }
    }

    return hasBlock;
}

private static string StripCoreBlockNamespace(string blockName)
{
    if (blockName.StartsWith("core/"))
    {
        return blockName.Substring(5);
    }
    return blockName;
}