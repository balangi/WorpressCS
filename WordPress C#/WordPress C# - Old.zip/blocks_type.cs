using System;
using System.Collections.Generic;

public class WP_Block_Type
{
    public string Name { get; set; }
    public string Title { get; set; }
    public string Category { get; set; }
    public Dictionary<string, object> Attributes { get; set; }
    public Dictionary<string, object> ProvidesContext { get; set; }
    public List<string> UsesContext { get; set; }
    public Dictionary<string, object> Supports { get; set; }
    public List<BlockStyle> Styles { get; set; }
    public List<BlockVariation> Variations { get; set; }
    public Dictionary<string, string[]> BlockHooks { get; set; }
    public string[] AllowedBlocks { get; set; }
    public Func<Dictionary<string, object>, string, WP_Block, string> RenderCallback { get; set; }
    public Func<Dictionary<string, object>> VariationCallback { get; set; }
    public string[] EditorScriptHandles { get; set; }
    public string[] ScriptHandles { get; set; }
    public string[] ViewScriptHandles { get; set; }
    public string[] ViewScriptModuleIds { get; set; }
    public string[] EditorStyleHandles { get; set; }
    public string[] StyleHandles { get; set; }
    public string[] ViewStyleHandles { get; set; }

    public WP_Block_Type(string name, Dictionary<string, object> args)
    {
        Name = name;
        // Initialize properties from args
        // This is a simplified version - actual implementation would map all properties
    }

    public bool IsDynamic()
    {
        return RenderCallback != null;
    }
}

public class BlockStyle
{
    public string Name { get; set; }
    public string Label { get; set; }
    // Other properties
}

public class BlockVariation
{
    public string Name { get; set; }
    public string Title { get; set; }
    // Other properties
}