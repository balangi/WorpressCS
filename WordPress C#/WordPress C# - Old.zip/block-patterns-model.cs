public class BlockPattern
{
    public string Name { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string Content { get; set; }
    public string Source { get; set; }
    public List<string> Categories { get; set; } = new List<string>();
    public List<string> BlockTypes { get; set; } = new List<string>();
    public List<string> PostTypes { get; set; } = new List<string>();
    public List<string> TemplateTypes { get; set; } = new List<string>();
    public int? ViewportWidth { get; set; }
    public string FilePath { get; set; }
}