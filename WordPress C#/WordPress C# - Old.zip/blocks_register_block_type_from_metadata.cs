public static WP_Block_Type RegisterBlockTypeFromMetadata(string fileOrFolder, Dictionary<string, object> args = null)
{
    args = args ?? new Dictionary<string, object>();
    
    // Normalize path
    string metadataFile = fileOrFolder.EndsWith("block.json", StringComparison.OrdinalIgnoreCase)
        ? fileOrFolder
        : System.IO.Path.Combine(fileOrFolder, "block.json");

    // Check if this is a core block
    bool isCoreBlock = metadataFile.StartsWith(GetWpIncPath());

    // Try to get metadata from registry first
    var metadata = WP_Block_Type_Registry.Instance.GetMetadata(fileOrFolder);
    
    // If not found in registry, load from file
    if (metadata == null && System.IO.File.Exists(metadataFile))
    {
        metadata = LoadMetadataFromFile(metadataFile);
        metadata.File = System.IO.Path.GetFullPath(metadataFile);
    }

    if (metadata == null || (string.IsNullOrEmpty(metadata.Name) && !args.ContainsKey("name")))
    {
        return null;
    }

    // Process metadata and create block type
    var settings = ProcessMetadata(metadata, args, isCoreBlock);

    // Register the block type
    string blockName = !string.IsNullOrEmpty(settings.Name) ? settings.Name : metadata.Name;
    return WP_Block_Type_Registry.Instance.Register(blockName, new WP_Block_Type(blockName, settings));
}

private static Dictionary<string, object> ProcessMetadata(BlockMetadata metadata, Dictionary<string, object> args, bool isCoreBlock)
{
    var settings = new Dictionary<string, object>();

    // Map properties from metadata to settings
    var propertyMappings = new Dictionary<string, string>
    {
        {"apiVersion", "api_version"},
        {"name", "name"},
        {"title", "title"},
        {"category", "category"},
        {"parent", "parent"},
        {"ancestor", "ancestor"},
        {"icon", "icon"},
        {"description", "description"},
        {"keywords", "keywords"},
        {"attributes", "attributes"},
        {"providesContext", "provides_context"},
        {"usesContext", "uses_context"},
        {"selectors", "selectors"},
        {"supports", "supports"},
        {"styles", "styles"},
        {"variations", "variations"},
        {"example", "example"},
        {"allowedBlocks", "allowed_blocks"}
    };

    // Process each property
    foreach (var mapping in propertyMappings)
    {
        if (metadata.ContainsKey(mapping.Key))
        {
            settings[mapping.Value] = metadata[mapping.Key];
        }
    }

    // Handle render callback
    if (metadata.ContainsKey("render"))
    {
        string renderPath = RemoveBlockAssetPathPrefix(metadata["render"].ToString());
        string templatePath = System.IO.Path.Combine(
            System.IO.Path.GetDirectoryName(metadata.File),
            renderPath
        );

        if (System.IO.File.Exists(templatePath))
        {
            settings["render_callback"] = (Func<Dictionary<string, object>, string, WP_Block, string>)(
                (attrs, content, block) => {
                    // In a real implementation, this would render the template
                    return $"Rendered content from {templatePath}";
                });
        }
    }

    // Handle script and style registration
    RegisterBlockAssets(metadata, settings, isCoreBlock);

    return settings;
}

private static void RegisterBlockAssets(BlockMetadata metadata, Dictionary<string, object> settings, bool isCoreBlock)
{
    // Register scripts
    var scriptFields = new Dictionary<string, string>
    {
        {"editorScript", "editor_script_handles"},
        {"script", "script_handles"},
        {"viewScript", "view_script_handles"}
    };

    foreach (var field in scriptFields)
    {
        if (metadata.ContainsKey(field.Key) || settings.ContainsKey(field.Key))
        {
            var scripts = metadata.ContainsKey(field.Key) ? metadata[field.Key] : settings[field.Key];
            var processedScripts = RegisterBlockScriptHandles(metadata, field.Key, scripts);
            settings[field.Value] = processedScripts;
        }
    }

    // Register styles
    var styleFields = new Dictionary<string, string>
    {
        {"editorStyle", "editor_style_handles"},
        {"style", "style_handles"},
        {"viewStyle", "view_style_handles"}
    };

    foreach (var field in styleFields)
    {
        if (metadata.ContainsKey(field.Key) || settings.ContainsKey(field.Key))
        {
            var styles = metadata.ContainsKey(field.Key) ? metadata[field.Key] : settings[field.Key];
            var processedStyles = RegisterBlockStyleHandles(metadata, field.Key, styles, isCoreBlock);
            settings[field.Value] = processedStyles;
        }
    }
}