[Table("BlockPatternCategories")]
public class BlockPatternCategoryEntity
{
    [Key]
    [StringLength(255)]
    public string Name { get; set; }

    [Required]
    [StringLength(255)]
    public string Label { get; set; }

    [Column(TypeName = "nvarchar(max)")]
    public string Description { get; set; }
}