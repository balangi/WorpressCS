/// <summary>
/// Manages CSS dependencies
/// </summary>
public class StylesService : DependenciesService
{
    /// <summary>
    /// Adds inline CSS to a stylesheet
    /// </summary>
    public void AddInlineStyle(string handle, string css)
    {
        if (!Registered.TryGetValue(handle, out var style))
            throw new InvalidOperationException($"Style '{handle}' is not registered.");

        style.ExtraAttributes["inline_style"] = css;
    }

    /// <summary>
    /// Sets the media type for a stylesheet
    /// </summary>
    public void SetMedia(string handle, string media)
    {
        if (!Registered.TryGetValue(handle, out var style))
            throw new InvalidOperationException($"Style '{handle}' is not registered.");

        style.ExtraAttributes["media"] = media;
    }
}