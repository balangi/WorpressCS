/// <summary>
/// Manages JavaScript dependencies
/// </summary>
public class ScriptsService : DependenciesService
{
    /// <summary>
    /// Adds localization data to a script
    /// </summary>
    public void Localize(string handle, string objectName, Dictionary<string, object> data)
    {
        if (!Registered.TryGetValue(handle, out var script))
            throw new InvalidOperationException($"Script '{handle}' is not registered.");

        script.ExtraAttributes["data"] = new Dictionary<string, object>
        {
            { "l10n", new { objectName, data } }
        };
    }

    /// <summary>
    /// Sets whether script should be loaded in footer
    /// </summary>
    public void SetInFooter(string handle, bool inFooter = true)
    {
        if (!Registered.TryGetValue(handle, out var script))
            throw new InvalidOperationException($"Script '{handle}' is not registered.");

        script.ExtraAttributes["in_footer"] = inFooter.ToString();
    }
}