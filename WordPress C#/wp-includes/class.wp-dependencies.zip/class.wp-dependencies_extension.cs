using System.Text;

public static class DependencyExtensions
{
    /// <summary>
    /// Generates HTML tag for a script dependency
    /// </summary>
    public static string ToScriptTag(this Dependency script)
    {
        var sb = new StringBuilder();
        sb.Append($"<script src=\"{script.Source}\"");

        if (!string.IsNullOrEmpty(script.Version))
        {
            sb.Append($" ver=\"{script.Version}\"");
        }

        foreach (var attr in script.ExtraAttributes)
        {
            if (attr.Key == "in_footer" && bool.Parse(attr.Value))
                continue; // Handled by placement in page

            sb.Append($" {attr.Key}=\"{attr.Value}\"");
        }

        sb.Append("></script>");
        return sb.ToString();
    }

    /// <summary>
    /// Generates HTML tag for a style dependency
    /// </summary>
    public static string ToStyleTag(this Dependency style)
    {
        var sb = new StringBuilder();
        sb.Append($"<link rel=\"stylesheet\" href=\"{style.Source}\"");

        if (!string.IsNullOrEmpty(style.Version))
        {
            sb.Append($" ver=\"{style.Version}\"");
        }

        foreach (var attr in style.ExtraAttributes)
        {
            sb.Append($" {attr.Key}=\"{attr.Value}\"");
        }

        sb.Append(" />");

        // Add inline styles if any
        if (style.ExtraAttributes.TryGetValue("inline_style", out var inlineStyle))
        {
            sb.Append($"<style>{inlineStyle}</style>");
        }

        return sb.ToString();
    }
}