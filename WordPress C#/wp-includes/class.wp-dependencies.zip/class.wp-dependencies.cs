using System;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// Base class for managing dependencies (scripts and styles)
/// </summary>
public class DependenciesService
{
    /// <summary>
    /// Registered dependencies
    /// </summary>
    protected Dictionary<string, Dependency> Registered { get; set; } = new Dictionary<string, Dependency>();

    /// <summary>
    /// Queue of dependencies to be loaded
    /// </summary>
    protected List<string> Queue { get; set; } = new List<string>();

    /// <summary>
    /// Adds a dependency
    /// </summary>
    public void Add(string handle, string source, List<string> dependencies = null, string version = null, Dictionary<string, string> extraAttributes = null)
    {
        if (string.IsNullOrEmpty(handle))
            throw new ArgumentException("Handle cannot be null or empty", nameof(handle));

        Registered[handle] = new Dependency
        {
            Handle = handle,
            Source = source,
            Dependencies = dependencies ?? new List<string>(),
            Version = version,
            ExtraAttributes = extraAttributes ?? new Dictionary<string, string>()
        };
    }

    /// <summary>
    /// Adds multiple dependencies
    /// </summary>
    public void Add(Dictionary<string, Dependency> dependencies)
    {
        foreach (var item in dependencies)
        {
            Registered[item.Key] = item.Value;
        }
    }

    /// <summary>
    /// Removes a dependency
    /// </summary>
    public void Remove(string handle)
    {
        if (Registered.ContainsKey(handle))
        {
            Registered.Remove(handle);
            Queue.Remove(handle);
        }
    }

    /// <summary>
    /// Enqueues a dependency to be loaded
    /// </summary>
    public void Enqueue(string handle)
    {
        if (!Registered.ContainsKey(handle))
            throw new InvalidOperationException($"Dependency '{handle}' is not registered.");

        if (!Queue.Contains(handle))
        {
            Queue.Add(handle);
        }
    }

    /// <summary>
    /// Dequeues a dependency
    /// </summary>
    public void Dequeue(string handle)
    {
        Queue.Remove(handle);
    }

    /// <summary>
    /// Gets all queued dependencies in the correct order
    /// </summary>
    public List<Dependency> GetQueue()
    {
        var sorted = new List<Dependency>();
        var visited = new Dictionary<string, bool>();

        foreach (var handle in Queue)
        {
            VisitDependencies(handle, visited, sorted);
        }

        return sorted;
    }

    /// <summary>
    /// Recursively visits dependencies to resolve correct loading order
    /// </summary>
    private void VisitDependencies(string handle, Dictionary<string, bool> visited, List<Dependency> sorted)
    {
        if (!Registered.ContainsKey(handle))
            return;

        // Check if we've already visited this node
        if (visited.TryGetValue(handle, out bool inProcess))
        {
            if (inProcess)
            {
                // Circular dependency detected
                throw new InvalidOperationException($"Circular dependency detected for '{handle}'");
            }
            return;
        }

        // Mark as being processed
        visited[handle] = true;

        // Process dependencies first
        var dependency = Registered[handle];
        foreach (var depHandle in dependency.Dependencies)
        {
            VisitDependencies(depHandle, visited, sorted);
        }

        // Mark as processed and add to sorted list
        visited[handle] = false;
        sorted.Add(dependency);
    }

    /// <summary>
    /// Gets all registered dependencies
    /// </summary>
    public Dictionary<string, Dependency> GetRegistered()
    {
        return new Dictionary<string, Dependency>(Registered);
    }

    /// <summary>
    /// Gets a single registered dependency
    /// </summary>
    public Dependency GetRegistered(string handle)
    {
        return Registered.TryGetValue(handle, out var dependency) ? dependency : null;
    }

    /// <summary>
    /// Checks if a dependency is registered
    /// </summary>
    public bool IsRegistered(string handle)
    {
        return Registered.ContainsKey(handle);
    }

    /// <summary>
    /// Checks if a dependency is enqueued
    /// </summary>
    public bool IsEnqueued(string handle)
    {
        return Queue.Contains(handle);
    }
}