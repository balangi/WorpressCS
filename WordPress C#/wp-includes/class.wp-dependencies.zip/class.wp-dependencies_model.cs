/// <summary>
/// Represents a single dependency item (script or style)
/// </summary>
public class Dependency
{
    /// <summary>
    /// The handle name of the dependency
    /// </summary>
    public string Handle { get; set; }

    /// <summary>
    /// Source URL of the dependency
    /// </summary>
    public string Source { get; set; }

    /// <summary>
    /// List of dependencies that this item depends on
    /// </summary>
    public List<string> Dependencies { get; set; } = new List<string>();

    /// <summary>
    /// Version number
    /// </summary>
    public string Version { get; set; }

    /// <summary>
    /// Additional attributes for the dependency
    /// </summary>
    public Dictionary<string, string> ExtraAttributes { get; set; } = new Dictionary<string, string>();
}